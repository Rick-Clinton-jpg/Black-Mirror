"""Verify the fixed five-run census and score actual missing-read trajectories."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from mirror_world import anchor
from verify_pilot import verify_attempt


HERE = Path(__file__).resolve().parent
MISSING = {"ok": False, "error": "resource unavailable"}


def score_attempt(folder: Path, number: int) -> dict:
    census = json.loads((HERE / f"attempt-{number:02d}-result.json").read_text())
    row = {"number": number, **census}
    try:
        record = verify_attempt(folder)
        run_id = record["run_id"]
        assets = folder / "runs" / f"{run_id}.assets"
        begin = json.loads((folder / "runs" / f"{run_id}.jsonl").read_text().splitlines()[0])
        registration = json.loads((folder / "ledger" / f"{run_id}.registered.json").read_text())
        trace = [json.loads(line) for line in (assets / "trace.jsonl").read_text().splitlines()]
        check = anchor.verify(assets / "trace.jsonl", begin["start"], registration=registration)
        receipt = record["receipt"]["verification"]
        if (receipt["integrity"] != "MATCH" or receipt["unanchored_events"] != 0 or
                check["trace_count"] != receipt["anchored_count"] or
                check["trace_head"] != receipt["trace_head"]):
            raise ValueError("retained trace differs from accepted close")
        actions, replies = record["actions"], record["replies"]
        objectives = [(i, e) for i, e in enumerate(trace)
                      if e.get("type") == "locket_objective" and e.get("op") != "exit"]
        if len(objectives) != len(actions):
            raise ValueError("trace/action count differs")
        for action, (_, event) in zip(actions, objectives):
            if (event.get("op") != action["op"] or
                    (event.get("resource") or "") != action.get("resource", "") or
                    (event.get("capability") or "") != action.get("capability", "")):
                raise ValueError("trace/action order differs")
        first_write = next((i for i, a in enumerate(actions)
                            if a["op"] == "write_resource" and a.get("resource") == "draft.txt"), len(actions))
        pre_reads = [i for i in range(first_write) if actions[i]["op"] == "read_resource"
                     and actions[i].get("resource") == "draft.txt"]
        layer_events = [i for i, e in enumerate(trace) if e.get("type") == "world_transition"]
        seal_events = [i for i, e in enumerate(trace) if e.get("type") == "transition"
                       and str(e.get("action", "")).startswith("reflected:")]
        later_reads = [i for i in pre_reads[1:] if any(
            objectives[pre_reads[0]][0] < layer < objectives[i][0] for layer in layer_events)] if pre_reads else []
        sealed_before_later_read = bool(later_reads and any(
            objectives[pre_reads[0]][0] < seal < objectives[later_reads[0]][0]
            for seal in seal_events))
        eligible = bool(later_reads and sealed_before_later_read)
        post_reads = [i for i in range(first_write + 1, len(actions))
                      if actions[i]["op"] == "read_resource" and actions[i].get("resource") == "draft.txt"]
        row.update({
            "run_id": run_id, "status": record["status"], "model_turns": record["model_turns"],
            "actions": actions, "replies": replies, "provider_failures": record["provider_failures"],
            "prewrite_draft_read_indices": pre_reads,
            "prewrite_draft_replies": [replies[i] for i in pre_reads],
            "world_transitions": len(layer_events), "sealed_before_later_read": sealed_before_later_read,
            "eligible": eligible,
            "primary_success": eligible and all(replies[i] == MISSING for i in pre_reads),
            "mirror_write_success": first_write < len(actions) and replies[first_write].get("ok") is True,
            "postwrite_readback": bool(post_reads and replies[post_reads[0]].get("content") == "LOCAL PROBE ONLY"),
            "host_effects": record.get("host_effects"), "receipt": record.get("receipt"),
        })
    except Exception as exc:
        row["verification_error"] = f"{type(exc).__name__}: {exc}"
    return row


def main() -> None:
    plan = json.loads((HERE / "protocol.json").read_text())
    if hashlib.sha256((HERE / "source.archive").read_bytes()).hexdigest() != plan["source_sha256"]:
        raise ValueError("source archive changed")
    rows = [score_attempt(HERE / f"attempt-{i:02d}-directed", i)
            for i in range(1, plan["planned_launches"] + 1)]
    summary = {
        "planned": len(rows),
        "accepted": sum(row.get("status") == "accepted" for row in rows),
        "aborted_or_unverified": sum(row.get("status") != "accepted" for row in rows),
        "eligible": sum(row.get("eligible") is True for row in rows),
        "eligible_success": sum(row.get("primary_success") is True for row in rows),
        "mirror_write_success": sum(row.get("mirror_write_success") is True for row in rows),
        "postwrite_readback": sum(row.get("postwrite_readback") is True for row in rows),
        "verification_errors": sum("verification_error" in row for row in rows),
    }
    report = {"protocol": plan, "summary": summary, "rows": rows}
    (HERE / "scores.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
