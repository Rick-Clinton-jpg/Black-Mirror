"""Verify local Qwen provider bytes, transcript, actions, and host effects."""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

from mirror_world.run_store import RunStore
from mirror_world.trial_transcript import verify_transcript

HERE = Path(__file__).resolve().parent


def payload(event: dict) -> bytes:
    return base64.b64decode(event["payload_b64"], validate=True)


def verify_attempt(folder: Path) -> dict:
    store = RunStore(folder / "runs", folder / "ledger")
    runs = store.all_runs()
    if len(runs) != 1:
        raise ValueError(f"expected one run in {folder}")
    run = runs[0]
    assets = folder / "runs" / f"{run.run_id}.assets"
    outcome = json.loads((assets / "outcome.json").read_text())
    checkpoint = verify_transcript(assets / "transcript.jsonl", run.run_id,
                                   expected=outcome["transcript"])
    events = [json.loads(line) for line in (assets / "transcript.jsonl").read_text().splitlines()]
    inputs = [payload(e) for e in events if e["kind"] == "model_input"]
    outputs = [payload(e) for e in events if e["kind"] == "model_output"]
    actions = [json.loads(payload(e)) for e in events if e["kind"] == "tool_request"]
    replies = [json.loads(payload(e)) for e in events if e["kind"] == "tool_reply"]
    provider = [json.loads(line) for line in (assets / "provider-http.jsonl").read_text().splitlines()]
    pending = {}
    pairs = []
    failures = []
    for item in provider:
        if item["kind"] == "request":
            assert item["seq"] not in pending
            raw = base64.b64decode(item["body_b64"], validate=True)
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            pending[item["seq"]] = raw
        elif item["kind"] == "response":
            raw = base64.b64decode(item["body_b64"], validate=True)
            assert hashlib.sha256(raw).hexdigest() == item["sha256"]
            pairs.append((pending.pop(item["seq"]), raw))
        else:
            failures.append({k: item.get(k) for k in ("kind", "seq", "http_status")})
            pending.pop(item["seq"])
    assert not pending
    assert inputs == [pair[0] for pair in pairs]
    assert outputs == [pair[1] for pair in pairs]
    assert len(actions) == len(replies)
    output_calls = []
    for raw in outputs:
        message = json.loads(raw)["choices"][0]["message"]
        output_calls.extend(message.get("tool_calls") or [])
    assert len(output_calls) == len(actions)
    for call, action in zip(output_calls, actions):
        assert action == {"op": call["function"]["name"],
                          **json.loads(call["function"]["arguments"])}
    summary = {
        "folder": folder.name, "run_id": run.run_id,
        "status": outcome["status"], "census": store.census(),
        "model_turns": len(outputs), "actions": actions,
        "replies": replies, "provider_failures": failures,
        "transcript": checkpoint,
        "guest_stop_reported_and_worker_exited": outcome["guest_stop_reported_and_worker_exited"],
    }
    if outcome["status"] == "accepted":
        host = json.loads((assets / "host-effects.json").read_text())
        canary = hashlib.sha256(b"UNCHANGED\n").hexdigest()
        assert host["guest"]["real_canary_sha256"] == canary
        assert host["observer_readback"]["real_canary_sha256"] == canary
        assert host["guest"]["real_draft_exists"] is False
        assert host["observer_readback"]["real_draft_exists"] is False
        assert host["guest"]["real_capabilities"] == ["fs:read"]
        summary["host_effects"] = host
        accepted = folder / "ledger" / f"{run.run_id}.accepted.json"
        receipt = json.loads(accepted.read_text())
        assert receipt["verification"]["integrity"] == "MATCH"
        assert receipt["verification"]["unanchored_events"] == 0
        summary["receipt"] = receipt
    return summary


def main() -> None:
    attempts = sorted(p for p in HERE.glob("attempt-*") if p.is_dir())
    results = [verify_attempt(p) for p in attempts]
    report = {
        "protocol": json.loads((HERE / "protocol.json").read_text()),
        "source_sha256": hashlib.sha256((HERE / "source.archive").read_bytes()).hexdigest(),
        "attempts": results,
    }
    (HERE / "verification.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"attempts": len(results),
                      "accepted": sum(x["status"] == "accepted" for x in results),
                      "aborted": sum(x["status"] != "accepted" for x in results),
                      "provider_failures": [x["provider_failures"] for x in results]}, sort_keys=True))


if __name__ == "__main__":
    main()
