"""Run the predeclared five Qwen missing-read launches once each."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "black-mirror-fidelity-publish"
MODEL = "qwen/qwen3-4b"


def save_new(path: Path, value: object) -> None:
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main() -> None:
    plan = json.loads((HERE / "protocol.json").read_text())
    order = plan["order"]
    if order != ["directed"] * 5:
        raise ValueError("expected five fixed directed launches")
    source_hash = hashlib.sha256((HERE / "source.archive").read_bytes()).hexdigest()
    if source_hash != plan["source_sha256"]:
        raise ValueError("source archive differs from predeclared protocol")
    env = dict(os.environ, PYTHONPATH=str(REPO))
    for number, condition in enumerate(order, 1):
        folder = HERE / f"attempt-{number:02d}-{condition}"
        result_path = HERE / f"attempt-{number:02d}-result.json"
        if result_path.exists():
            continue
        if folder.exists():
            raise RuntimeError(f"incomplete launch requires review: {folder}")
        started = datetime.now(timezone.utc).isoformat()
        with (HERE / f"attempt-{number:02d}.stdout").open("x") as out, \
             (HERE / f"attempt-{number:02d}.stderr").open("x") as err:
            try:
                result = subprocess.run(
                    [sys.executable, str(HERE / "qwen_trial.py"),
                     "--model", MODEL, "--arm", "reflect",
                     "--condition", condition, "--output", str(folder)],
                    cwd=HERE, env=env, stdout=out, stderr=err,
                    timeout=1900, check=False,
                )
                exit_code, timed_out = result.returncode, False
            except subprocess.TimeoutExpired:
                exit_code, timed_out = None, True
        save_new(result_path, {
            "number": number, "condition": condition, "started_utc": started,
            "ended_utc": datetime.now(timezone.utc).isoformat(),
            "exit_code": exit_code, "outer_timeout": timed_out,
        })
        print(f"{number:02d}/05 {condition} exit={exit_code} timeout={timed_out}", flush=True)


if __name__ == "__main__":
    main()
