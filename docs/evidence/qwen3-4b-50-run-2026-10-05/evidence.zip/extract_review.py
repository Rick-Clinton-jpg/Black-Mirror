"""Extract every launch's model final and action sequence for manual scoring."""

from __future__ import annotations

import base64
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def main() -> None:
    order = json.loads((HERE / "trial-order.json").read_text())["arms"]
    rows = []
    for number, arm in enumerate(order, 1):
        folder = HERE / f"attempt-{number:02d}-{arm}"
        result_path = HERE / f"attempt-{number:02d}-result.json"
        result = json.loads(result_path.read_text()) if result_path.exists() else None
        transcripts = list((folder / "runs").glob("*.assets/transcript.jsonl"))
        outcomes = list((folder / "runs").glob("*.assets/outcome.json"))
        if len(transcripts) > 1 or len(outcomes) > 1:
            raise ValueError(f"multiple runs in attempt {number}")
        actions = []
        outputs = []
        if transcripts:
            for line in transcripts[0].read_text().splitlines():
                event = json.loads(line)
                if event["kind"] == "tool_request":
                    actions.append(json.loads(base64.b64decode(event["payload_b64"])))
                if event["kind"] == "model_output":
                    outputs.append(json.loads(base64.b64decode(event["payload_b64"])))
        final = None
        if outputs:
            choice = outputs[-1]["choices"][0]
            if choice.get("finish_reason") == "stop":
                final = choice["message"].get("content")
        outcome = json.loads(outcomes[0].read_text()) if outcomes else None
        rows.append({
            "number": number, "arm": arm, "result": result,
            "outcome": outcome and outcome.get("status"),
            "run_id": outcome and outcome.get("run_id"),
            "actions": actions, "model_turns": len(outputs),
            "final_text": final,
        })
    (HERE / "manual-review.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n")
    for row in rows:
        action_list = ",".join(action["op"] for action in row["actions"])
        final = (row["final_text"] or "").replace("\n", " ").replace("\t", " ")
        print(f"{row['number']:02d} {row['arm']:7s} {str(row['outcome']):8s} "
              f"{action_list:60s} {final[:240]}")


if __name__ == "__main__":
    main()
