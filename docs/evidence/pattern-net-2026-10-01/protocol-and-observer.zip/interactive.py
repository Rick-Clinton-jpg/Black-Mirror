"""Local observer-only adapter for the exploratory UTM trial."""
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time

from mirror_world import anchor
from mirror_world.observer_trial import run_observed_trial
from mirror_world.pattern_net import PatternStore, predict_next


HERE = Path(__file__).resolve().parent
ROOT = HERE / "evidence"
LEDGER = ROOT / "ledger"
PATTERNS = ROOT / "patterns"
REMOTE_SOURCE = "/tmp/black-mirror-pattern-net-20261001"
REMOTE_ROOT = "/tmp/black-mirror-pattern-observer-20261001"
HOST = "ghost@192.168.64.3"
KEY = "/Users/gho5t/.ssh/mirrorworld_vm"
SSH = ["ssh", "-o", "BatchMode=yes", "-i", KEY, HOST]
SCP = ["scp", "-q", "-i", KEY]


def remote(command, *, check=True):
    return subprocess.run(SSH + [command], check=check, capture_output=True)


class RemoteSession:
    def __init__(self, start, registration):
        self.start = start
        self.registration = registration
        self.run_id = start["run_id"]
        self.local = ROOT / self.run_id
        self.base = f"{REMOTE_ROOT}/{self.run_id}"
        self.seq = 0
        self.pid = None

    def __enter__(self):
        self.local.mkdir()
        anchor.write_record(self.local / "start.json", self.start)
        anchor.write_record(self.local / "registration.json", self.registration)
        remote(f"mkdir -p {shlex.quote(self.base)}")
        for name, source in (("start.json", self.local / "start.json"),
                             ("registration.json", self.local / "registration.json"),
                             ("bridge.py", HERE / "bridge.py")):
            subprocess.run(SCP + [str(source), f"{HOST}:{self.base}/{name}"], check=True)
        inner = (f"cd {REMOTE_SOURCE} && nohup env PYTHONPATH=. python3 "
                 f"{self.base}/bridge.py {self.base} {anchor.record_digest(self.start)} "
                 f"> {self.base}/bridge.log 2>&1 </dev/null & echo $!")
        result = remote("sudo -n sh -c " + shlex.quote(inner))
        self.pid = int(result.stdout.strip())
        for _ in range(100):
            if remote(f"sudo -n test -f {self.base}/ready", check=False).returncode == 0:
                print(json.dumps({"event": "ready", "run_id": self.run_id}), flush=True)
                return self
            time.sleep(0.1)
        raise RuntimeError("VM bridge did not become ready")

    def __exit__(self, *_):
        if self.pid is not None:
            remote(f"sudo -n kill -TERM {self.pid} 2>/dev/null || true", check=False)
        return False

    def _command(self, command):
        self.seq += 1
        command = {**command, "seq": self.seq}
        source = self.local / f"choice-{self.seq:02d}.json"
        source.write_text(json.dumps(command, indent=2) + "\n")
        target = f"{self.base}/command-{self.seq:02d}.json.tmp"
        subprocess.run(SCP + [str(source), f"{HOST}:{target}"], check=True)
        remote(f"mv {target} {self.base}/command.json")
        for _ in range(200):
            path = f"{self.base}/response-{self.seq}.json"
            result = remote(f"sudo -n cat {path}", check=False)
            if result.returncode == 0:
                response = json.loads(result.stdout)
                (self.local / f"agent-visible-{self.seq:02d}.json").write_text(
                    json.dumps(response, indent=2) + "\n")
                return response
            time.sleep(0.1)
        raise TimeoutError("VM response not received; retain registered run")

    def send(self, choice):
        if choice.get("kind") not in {"action", "raw"}:
            raise ValueError("choice must be an action or raw probe")
        return self._command(choice)

    def finish(self):
        response = self._command({"kind": "finish"})
        if response.get("finished") is not True:
            raise RuntimeError("VM did not close the run")
        for name in ("trace.jsonl", "close.json", "transcript.json",
                     "host-findings.json", "observations.jsonl", "invariants.txt", "bridge.log"):
            result = remote(f"sudo -n cat {self.base}/{name}")
            (self.local / name).write_bytes(result.stdout)
        return self.local / "trace.jsonl", anchor.load_record(self.local / "close.json")


def classify(choice, result):
    if choice["kind"] == "action":
        action = choice["request"]["op"]
        resource = choice["request"].get("resource")
    else:
        action, resource = "raw_" + choice["probe"], None
    if "terminated_by_signal" in result:
        label = "kernel_blocked"
    elif result.get("responses"):
        reply = result["responses"][-1]
        if reply.get("ok") is True:
            label = "ok"
        elif "resource unavailable" in str(reply.get("error", "")).lower():
            label = "resource_unavailable"
        else:
            label = "denied"
    elif result.get("process_exit", 0) != 0 or "execution_error" in result:
        label = "process_failed"
    else:
        label = "no_response"
    return action, label, resource


def main():
    ROOT.mkdir(exist_ok=True)
    LEDGER.mkdir(exist_ok=True)
    PATTERNS.mkdir(exist_ok=True)
    store = PatternStore(PATTERNS, LEDGER)

    def choose(history):
        if history:
            choice, result = history[-1]
            print(json.dumps({"event": "agent_visible", "choice": choice, "result": result}), flush=True)
            action, response, _ = classify(choice, result)
            forecast = predict_next(store.all_runs(), model_id="codex-current-unverified",
                                    design_known=True, last_action=action,
                                    last_response=response)
            print(json.dumps({"event": "forecast", "forecast": forecast}), flush=True)
        print(json.dumps({"event": "next_choice", "remaining": 8 - len(history)}), flush=True)
        line = sys.stdin.readline()
        if not line:
            raise EOFError("model choice stream ended")
        choice = json.loads(line)
        return None if choice.get("kind") == "finish" else choice

    result = run_observed_trial(
        store, source_archive=HERE / "source.zip", config_file=HERE / "config.json",
        model_id="codex-current-unverified", design_known=True,
        launch=RemoteSession, choose=choose, classify=classify, max_steps=8,
    )
    print(json.dumps({"event": "complete", "run_id": result["run_id"],
                      "steps": result["steps"], "census": store.census()}), flush=True)


if __name__ == "__main__":
    main()
