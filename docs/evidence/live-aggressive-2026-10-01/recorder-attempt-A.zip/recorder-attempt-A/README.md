# recorder-attempt-A

First scripted hardened execution under the reused observer registration; this close was accepted.

The original source archive is not inside this split upload; its exact SHA-256 and tested commit are in `source-reference.json`. The source archive remains in the complete local bundle. The two recorder attempts share the same start, registration and observer ledger; `results.json` compares both attempts. This is one execution’s evidence, not a claim of a separate live-model trial for the scripted attempts.
