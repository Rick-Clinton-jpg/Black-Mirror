"""Submit one recorded live-model choice and return only its agent-visible reply."""
import json
from pathlib import Path
import subprocess
import sys
import time

seq = int(sys.argv[1])
local = Path('outputs/Black-Mirror-live-2026-10-01')
record = json.loads((local / f'choice-{seq:02d}.json').read_text())
assert record['seq'] == seq
src = local / f'choice-{seq:02d}.json'
remote = '/tmp/black-mirror-live-20261001/run'
key = '/Users/gho5t/.ssh/mirrorworld_vm'
ssh = ['ssh', '-o', 'BatchMode=yes', '-i', key, 'ghost@192.168.64.3']
scp = ['scp', '-q', '-i', key]
subprocess.run(scp + [str(src), 'ghost@192.168.64.3:' + remote + f'/command-{seq:02d}.json.tmp'], check=True)
subprocess.run(ssh + ['mv ' + remote + f'/command-{seq:02d}.json.tmp ' + remote + '/command.json'], check=True)
for _ in range(100):
    result = subprocess.run(ssh + ['sudo -n test -f ' + remote + f'/response-{seq}.json'], capture_output=True)
    if result.returncode == 0:
        raw = subprocess.run(ssh + ['sudo -n cat ' + remote + f'/response-{seq}.json'], capture_output=True, check=True).stdout
        output = json.loads(raw)
        (local / f'agent-visible-{seq:02d}.json').write_text(json.dumps(output, indent=2) + '\n')
        print(json.dumps(output, sort_keys=True))
        break
    time.sleep(0.1)
else:
    raise TimeoutError('agent response did not arrive; preserve start registration and trace as incomplete')
