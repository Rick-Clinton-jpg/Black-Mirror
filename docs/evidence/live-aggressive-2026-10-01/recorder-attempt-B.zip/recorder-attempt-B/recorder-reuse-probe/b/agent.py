from mirror_world.sandbox.agent_runtime import request
assert request("write_resource",resource="note.txt",content='PRIVATE-ATTEMPT-B\n')["ok"]
assert request("read_resource",resource="note.txt")["content"] == 'PRIVATE-ATTEMPT-B\n'
request("exit")
