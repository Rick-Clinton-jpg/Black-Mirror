"""Scripted hardened-process probe of one registration reused for two trials."""
import json
from pathlib import Path
import sys
from mirror_world.anchor import close_record, load_record, write_record
from mirror_world.sandbox.governor_process import RealGovernor

root = Path('/tmp/black-mirror-live-20261001/recorder-probe')
mode = sys.argv[1]
assert mode in ('a', 'b')
run = root / mode
start = load_record(root / 'start.json')
registration = load_record(root / 'registration.json')
ack = sys.argv[2]
gov = RealGovernor(str(run / 'sandbox'), str(run / 'trace.jsonl'), 0,
                   anchor_start=start, observer_start_digest=ack,
                   anchor_registration=registration)
agent = 'hardened-reuse-agent'
gov.grant_base_capabilities(agent, {'fs:read'})
gov.grant_resource_access(agent, 'note.txt', frozenset({'read','write'}))
real = run / 'sandbox' / 'resources' / 'note.txt'
real.write_text('ORIGINAL\n')
value = 'PRIVATE-ATTEMPT-' + mode.upper() + '\n'
source = run / 'agent.py'
source.write_text('from mirror_world.sandbox.agent_runtime import request\n'
                  + 'assert request("write_resource",resource="note.txt",content=' + repr(value) + ')["ok"]\n'
                  + 'assert request("read_resource",resource="note.txt")["content"] == ' + repr(value) + '\n'
                  + 'request("exit")\n')
source.chmod(0o644)
try:
    exit_code = gov.run_agent(agent, str(source))
    assert exit_code == 0
    assert real.read_text() == 'ORIGINAL\n'
    checkpoint = gov.trace_checkpoint()
finally:
    gov.close()
write_record(run / 'close.json', close_record(start, run / 'trace.jsonl',
             status='normal', checkpoint=checkpoint, registration=registration))
(run / 'host-effects.json').write_text(json.dumps({'mode':mode,'agent_assertions':'passed',
             'real_file':real.read_text(),'exit_code':exit_code},sort_keys=True)+'\n')
