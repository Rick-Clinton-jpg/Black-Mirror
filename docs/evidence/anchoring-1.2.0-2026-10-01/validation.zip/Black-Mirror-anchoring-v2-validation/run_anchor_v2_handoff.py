import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

from mirror_world import anchor

root = Path('/Users/gho5t/Documents/Codex/2026-09-30/new-chat')
evidence = root / 'outputs/Black-Mirror-anchoring-v2-validation'
probe = root / 'work/anchoring_handoff_probe_v2.py'
source = (root / 'work/anchoring_handoff_probe.py').read_text()
source = source.replace('anchor_start=start, observer_start_digest=args.ack)', 'anchor_start=start, observer_start_digest=args.ack,\n                   anchor_registration=load_record(root / "registration.json"))')
source = source.replace('status=status, checkpoint=checkpoint)', 'status=status, checkpoint=checkpoint,\n                                                         registration=load_record(root / "registration.json"))')
probe.write_text(source)
(evidence / probe.name).write_text(source)
key = '/Users/gho5t/.ssh/mirrorworld_vm'
ssh = ['ssh', '-o', 'BatchMode=yes', '-i', key, 'ghost@192.168.64.3']
scp = ['scp', '-q', '-i', key]
remote = '/tmp/black-mirror-anchoring-v2-20261001'
remote_runs = '/tmp/black-mirror-anchor-v2-handoff'
subprocess.run(scp + [str(probe), 'ghost@192.168.64.3:/tmp/anchoring_handoff_probe_v2.py'], check=True)
ledger = evidence / 'observer-ledger'
ledger.mkdir(mode=0o700)
results = []
for mode in ('normal', 'early', 'abrupt'):
    local = evidence / 'handoff' / mode
    local.mkdir(parents=True)
    run_dir = remote_runs + '/' + mode
    config = {'fixture': 'reflected-write-v2', 'mode': mode, 'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest()}
    config_path = local / 'config.json'
    config_path.write_text(json.dumps(config, sort_keys=True))
    subprocess.run(ssh + ['mkdir -p ' + shlex.quote(run_dir)], check=True)
    subprocess.run(scp + [str(config_path), 'ghost@192.168.64.3:' + run_dir + '/config.json'], check=True)
    command = ('cd ' + shlex.quote(remote) + ' && PYTHONPATH=' + shlex.quote(remote) +
               ' python3 -m mirror_world.anchor start --source /tmp/Black-Mirror-1.2.0-anchoring-candidate.zip --config ' +
               shlex.quote(run_dir + '/config.json') + ' --output ' + shlex.quote(run_dir + '/start.json'))
    subprocess.run(ssh + [command], check=True, capture_output=True)
    start_path = local / 'retained-start.json'
    subprocess.run(scp + ['ghost@192.168.64.3:' + run_dir + '/start.json', str(start_path)], check=True)
    start = anchor.load_record(start_path)
    assert start['source_sha256'] == anchor.file_digest(root / 'outputs/Black-Mirror-1.2.0-anchoring-candidate.zip')
    assert start['config_sha256'] == anchor.file_digest(config_path)
    registration = anchor.register_start(start, ledger)
    reg_path = ledger / (start['run_id'] + '.registered.json')
    # Only after independent retention and issuance is the challenge sent back.
    subprocess.run(scp + [str(reg_path), 'ghost@192.168.64.3:' + run_dir + '/registration.json'], check=True)
    ack = anchor.record_digest(start)
    command = ('sudo -n env PYTHONPATH=' + shlex.quote(remote) +
               ' python3 /tmp/anchoring_handoff_probe_v2.py ' + shlex.quote(run_dir) + ' ' + shlex.quote(ack) + ' ' + mode)
    execution = subprocess.run(ssh + [command], capture_output=True, text=True)
    assert execution.returncode == (17 if mode == 'abrupt' else 0), execution.stderr
    for name in ['trace.jsonl', 'host-effects.json'] + ([] if mode == 'abrupt' else ['close.json', 'writer-checkpoint.json']):
        raw = subprocess.run(ssh + ['sudo -n cat ' + shlex.quote(run_dir + '/' + name)], check=True, capture_output=True).stdout
        (local / name).write_bytes(raw)
    closing = anchor.load_record(local / 'close.json') if mode != 'abrupt' else None
    result = anchor.verify(local / 'trace.jsonl', start, closing, registration=registration)
    (local / 'verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    effects = json.loads((local / 'host-effects.json').read_text())
    assert effects['real_file'] == 'original' and effects['agent_assertions'] == 'passed'
    duplicate_exit = None
    if closing:
        receipt = anchor.accept_close(local / 'trace.jsonl', start, closing, ledger)
        # A fresh process must not accept the same registration a second time.
        duplicate = subprocess.run([sys.executable, '-m', 'mirror_world.anchor', 'accept', '--start', str(start_path),
                                    '--close', str(local / 'close.json'), '--trace', str(local / 'trace.jsonl'),
                                    '--ledger', str(ledger)], capture_output=True, text=True)
        duplicate_exit = duplicate.returncode
        assert duplicate_exit == 2
        (local / 'duplicate-acceptance.json').write_text(duplicate.stderr)
        assert receipt['close_sha256'] == anchor.record_digest(closing)
    results.append({'mode': mode, 'run_id': start['run_id'], 'start_ack_sha256': ack,
                    'registration_sha256': anchor.record_digest(registration), 'execution_exit': execution.returncode,
                    'duplicate_accept_exit': duplicate_exit, 'verification': result, 'host_effects': effects})
    print(mode, result['integrity'], result['completion'], flush=True)
(evidence / 'handoff-receipt.json').write_text(json.dumps({'trials': results, 'model_calls': 0,
    'observer': 'Mac outside Linux VM', 'order': 'VM start retained on Mac; Mac issues and retains registration; sends nonce; launches VM fixture; retains trace/close; verifies; accepts once'}, indent=2, sort_keys=True) + '\n')
