"""Trusted Linux smoke fixture, launched only after the Mac retains a start."""
import argparse
import json
import os
from pathlib import Path
import tempfile

from mirror_world.anchor import close_record, load_record, write_record
from mirror_world.sandbox.governor_process import RealGovernor

parser = argparse.ArgumentParser()
parser.add_argument("run_dir")
parser.add_argument("ack")
parser.add_argument("mode", choices=("normal", "early", "abrupt"))
args = parser.parse_args()
root = Path(args.run_dir)
start = load_record(root / "start.json")
gov = RealGovernor(str(root / "sandbox"), str(root / "trace.jsonl"), 0,
                   anchor_start=start, observer_start_digest=args.ack,
                   anchor_registration=load_record(root / "registration.json"))
status = "normal"
try:
    gov.grant_base_capabilities("worker", {"fs:read"})
    gov.grant_resource_access("worker", "note.txt", frozenset({"read", "write"}))
    real = root / "sandbox" / "resources" / "note.txt"
    real.write_text("original")
    with tempfile.TemporaryDirectory(prefix="bm-handoff-agent-") as directory:
        Path(directory).chmod(0o755)
        source = Path(directory) / "worker.py"
        source.write_text(
            'from mirror_world.sandbox.agent_runtime import request\n'
            'assert request("write_resource", resource="note.txt", content="reflected")["ok"]\n'
            'assert request("read_resource", resource="note.txt")["content"] == "reflected"\n'
            'request("exit")\n'
        )
        source.chmod(0o644)
        assert gov.run_agent("worker", str(source)) == 0
    assert real.read_text() == "original"
    (root / "host-effects.json").write_text(json.dumps({"real_file": real.read_text(), "agent_assertions": "passed", "mode": args.mode}))
    if args.mode == "abrupt":
        os._exit(17)  # no finally, writer checkpoint or closing record
    if args.mode == "early":
        raise RuntimeError("injected trial interruption")
except RuntimeError as exc:
    if args.mode != "early" or str(exc) != "injected trial interruption":
        raise
    status = "early"
finally:
    checkpoint = gov.trace_checkpoint()
    gov.close()
    (root / "writer-checkpoint.json").write_text(json.dumps(checkpoint))
write_record(root / "close.json", close_record(start, root / "trace.jsonl", status=status, checkpoint=checkpoint,
                                                         registration=load_record(root / "registration.json")))
