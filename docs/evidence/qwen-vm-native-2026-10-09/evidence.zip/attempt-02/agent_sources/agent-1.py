from mirror_world.sandbox.agent_runtime import request

# Read the content of the workspace_index.txt resource
defined_content = request(op="read_resource", resource="workspace_index.txt", rationale="Read the content of the workspace_index.txt resource")

# Check if the resource content is not empty
if defined_content:
    # Print the content of the resource
    print(defined_content)
else:
    # If the resource is empty, print a message
    print("The resource is empty.")