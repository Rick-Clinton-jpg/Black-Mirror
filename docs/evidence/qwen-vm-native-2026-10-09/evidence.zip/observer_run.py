"""Register and collect exactly one VM-local Qwen run; never retry it."""

from __future__ import annotations

import hashlib
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from mirror_world import anchor

HERE = Path(__file__).resolve().parent
PRIOR_SOURCE = HERE.parent / "qwen-free-five-20261009" / "source.archive"
DEST = "ghost@192.168.64.3"
IDENTITY = "/Users/gho5t/.ssh/mirrorworld_vm"
MODEL_SHA = "d0c2ac093a77c402f2ddc23a64f68b7c70cfef151899b33e3a6066247104ced3"
MODEL_PATH = "/var/tmp/bm-qwen3-4b-q4_k_m.gguf"
LLAMA_COMMIT = "8a1a9b5126126e5228b95fa909d4b08fac65e8b3"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def _run(args: list[str], *, timeout: int = 90, check: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=timeout, check=False)
    if check and result.returncode:
        raise RuntimeError(f"command failed ({result.returncode}): {args[0]}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--attempt", choices=("02", "03"), required=True)
    args = parser.parse_args()
    output = HERE / f"attempt-{args.attempt}"
    if output.exists():
        raise RuntimeError("attempt already exists; refusing a retry")
    output.mkdir()
    ledger = output / "ledger"
    ledger.mkdir()
    source = HERE / "source.archive" if args.attempt == "03" else PRIOR_SOURCE
    shutil.copyfile(source, output / "source.archive")
    probe = _run(["ssh", "-i", IDENTITY, "-o", "BatchMode=yes", DEST,
                  "cd /var/tmp/bm-vm-local && sudo -n env PYTHONPATH=$PWD python3 scripts/check_kernel.py"])
    (output / "kernel-probe.txt").write_bytes(probe.stdout + probe.stderr)
    if probe.stdout != b"Containment probe exit: 0\nmirror-kernel-ready\n\n\n":
        raise RuntimeError("kernel probe did not print exact success")
    boot = _run(["ssh", "-i", IDENTITY, "-o", "BatchMode=yes", DEST,
                 "cat /proc/sys/kernel/random/boot_id"]).stdout.decode().strip()
    config = {
        "kind": "one exploratory VM-local Qwen agent run",
        "base_commit": "c12ade127bab36767c994347e9e8609b79fc38fe",
        "source_variant": ("trial_no_policy_stop plus separate print output"
                           if args.attempt == "03" else "qwen-free-five-20261009 trial_no_policy_stop"),
        "model_path": MODEL_PATH,
        "model_sha256": MODEL_SHA,
        "llama_cpp_commit": LLAMA_COMMIT,
        "llama_cpp_reasoning": "off",
        "runner_sha256": _sha(HERE / "guest_run.py"),
        "max_decisions": 5,
        "vm_boot_id": boot,
        "vm_launch": "UTM disposable boot, started before registration",
        "boundary": "Qwen inference on VM host; model-generated Python under Black Mirror namespaces/seccomp",
    }
    _json(output / "config.json", config)
    start = anchor.start_record(_sha(output / "source.archive"), _sha(output / "config.json"))
    anchor.write_record(output / "start.json", start)
    registration = anchor.register_start(start, ledger)
    anchor.write_record(output / "registration.json", registration)
    run_id = start["run_id"]
    remote = f"/var/tmp/bm-vm-run-{run_id}"
    _run(["ssh", "-i", IDENTITY, "-o", "BatchMode=yes", DEST,
          f"mkdir -m 755 {remote}"])
    for name in ("source.archive", "config.json", "start.json", "registration.json", "guest_run.py"):
        path = HERE / name if name == "guest_run.py" else output / name
        _run(["scp", "-q", "-i", IDENTITY, str(path), f"{DEST}:{remote}/{name}"], timeout=120)
    guest = _run(["ssh", "-i", IDENTITY, "-o", "BatchMode=yes", DEST,
                  f"sudo -n env PYTHONPATH=/var/tmp/bm-vm-local python3 {remote}/guest_run.py --run-dir {remote}"],
                 timeout=1800, check=False)
    (output / "guest.stdout").write_bytes(guest.stdout)
    (output / "guest.stderr").write_bytes(guest.stderr)
    _json(output / "guest-exit.json", {"exit_code": guest.returncode})
    for name in ("trace.jsonl", "close.json", "outcome.json", "provider-http.jsonl",
                 "decisions.jsonl", "governor-replies.jsonl", "prompt.json", "real-canary.txt"):
        result = _run(["scp", "-q", "-i", IDENTITY, f"{DEST}:{remote}/{name}",
                       str(output / name)], timeout=90, check=False)
        if result.returncode:
            _json(output / f"missing-{name}.json", {"scp_exit": result.returncode})
    _run(["scp", "-q", "-r", "-i", IDENTITY, f"{DEST}:{remote}/agent_sources",
          str(output / "agent_sources")], timeout=90, check=False)
    if guest.returncode == 0:
        close = anchor.load_record(output / "close.json")
        result = anchor.verify(output / "trace.jsonl", start, close, registration=registration)
        _json(output / "verification.json", result)
        if result["integrity"] != "MATCH":
            raise RuntimeError("trace did not match retained close")
        receipt = anchor.accept_close(output / "trace.jsonl", start, close, ledger)
        _json(output / "accepted-receipt.json", receipt)
    print(json.dumps({"run_id": run_id, "guest_exit": guest.returncode,
                      "accepted": (output / "accepted-receipt.json").exists()}, sort_keys=True))
    return 0 if guest.returncode == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
